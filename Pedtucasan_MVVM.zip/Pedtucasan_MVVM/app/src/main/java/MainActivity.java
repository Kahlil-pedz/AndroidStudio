import android.os.Bundle;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 1. Find the ListView in your activity_main.xml layout
        ListView foodListView = findViewById(R.id.foodListView);

        // 2. Create the data source for the menu
        ArrayList<FoodItem> foodList = new ArrayList<>();
        foodList.add(new FoodItem("Cheeseburger", "P 95"));
        foodList.add(new FoodItem("French Fries", "P 55"));
        foodList.add(new FoodItem("Chicken Nuggets", "P 45"));
        foodList.add(new FoodItem("Soda", "$1.99"));
        foodList.add(new FoodItem("Milkshake", "$4.99"));
        foodList.add(new FoodItem("Hot Dog", "$5.00"));
        foodList.add(new FoodItem("Onion Rings", "$4.50"));

        // 3. Create an instance of your custom adapter
        FoodAdapter adapter = new FoodAdapter(this, foodList);

        // 4. Set the adapter on the ListView
        foodListView.setAdapter(adapter);
    }
}
