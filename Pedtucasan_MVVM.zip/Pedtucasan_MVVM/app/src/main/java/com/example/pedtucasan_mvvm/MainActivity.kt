package com.example.pedtucasan_mvvm

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.pedtucasan_mvvm.ui.theme.Pedtucasan_MVVMTheme

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppComponentActivity() {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(saved)
    }
    }