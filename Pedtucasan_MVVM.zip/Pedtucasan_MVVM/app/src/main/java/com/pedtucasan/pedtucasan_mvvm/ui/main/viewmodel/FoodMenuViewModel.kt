package com.pedtucasan.pedtucasan_mvvm.ui.main.viewmodel

import androidx.lifecycle.ViewModel
import com.pedtucasan.pedtucasan_mvvm.model.FoodItem

class FoodMenuViewModel : ViewModel() {

    val foodItems = listOf(
        FoodItem("Pizza", "Delicious pizza with your favorite toppings", 12.99),
        FoodItem("Burger", "Juicy beef burger with cheese and fries", 8.99),
        FoodItem("Salad", "Healthy salad with fresh vegetables and dressing", 6.99),
        FoodItem("Pasta", "Creamy pasta with a rich and flavorful sauce", 10.99),
        FoodItem("Soup", "Warm and comforting soup, perfect for a cold day", 4.99)
    )
}
